#ifndef _fibo_h_
#define _fibo_h_

#include "matrix.h"

long int fibo(int n);

#endif