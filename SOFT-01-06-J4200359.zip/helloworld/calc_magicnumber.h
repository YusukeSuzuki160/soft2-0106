#ifndef _calc_magicnumber_h_
#define _calc_magicnumber_h_

#include <stdio.h>
#include <stdlib.h>

float char_to_f32(char *c);
int slength(char *s);
float *parse_char_to_f32(char *s);

#endif